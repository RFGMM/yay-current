# [Donaciones / Donations](paypal.me/codigocristo)

[paypal.me/codigocristo](paypal.me/codigocristo)

# ArcriS 3.0.2022

1. Descarga la ISO de Arch Linux Oficial.
2. Descargar el Script y ejecutalo.


![Captura 2](https://github.com/CodigoCristo/arcris/blob/master/capturas/present.png)


![Captura 1](https://github.com/CodigoCristo/arcris/blob/master/capturas/main.png)


# Como descargar el instalador en la ISO

> Método 1
```
loadkeys es
curl -L is.gd/arcris > arcris ; sh arcris
```

> Método 2
```
loadkeys es
pacman -Sy wget --noconfirm
wget is.gd/arcris ; sh arcris
```

> Método 3
```
pacman -Sy wget --noconfirm
wget https://raw.githubusercontent.com/CodigoCristo/arcris/master/arcris
sh arcris
```

> Método 4
```
pacman -Sy git --noconfirm
git clone https://github.com/CodigoCristo/arcris
cd arcris
sh arcris
```


